---
name: dotnet-testing
description: Testing code that calls an APIMatic-generated .NET SDK in C# — which seam to fake, covering error and edge paths, asserting real behaviour rather than execution, and keeping tests independent of SDK internals. Load before writing tests for the integration layer.
---

# Testing code that uses an APIMatic .NET SDK

The client takes an `HttpClient` in its constructor, which is the seam for testing: pass an `HttpClient`
backed by a fake `HttpMessageHandler`, so no real network calls happen. The SDK ships no mocking helpers —
this is standard .NET.

**Match the project's existing test stack — don't impose one.** Check the test project's package references
and existing tests, then mirror both its **test framework** (xUnit / NUnit / MSTest) and its **assertion
style**: if it uses an assertion library such as FluentAssertions or Shouldly, write assertions that way
(e.g. `result.StatusCode.Should().Be(HttpStatusCode.OK)`) rather than the framework's built-in asserts. The
code samples below use xUnit `[Fact]` + the built-in `Assert` **purely for reference** — they show the SDK
testing seam and *what* to assert, not a mandated framework or assertion library. Substitute your
`{Api}Client`/`{Api}ClientOptions` as well.

> Throughout this skill, `{...}` is a placeholder for a name you take from your SDK (e.g. `{Api}Client`,
> `{ApiGroup}`, `{Operation}`) — replace it with the concrete identifier from the source.

## A reusable stub handler

```csharp
using System.Net;

public sealed class StubHandler : HttpMessageHandler
{
    private readonly Func<HttpRequestMessage, HttpResponseMessage> _responder;

    // Every request, in order — retries append, so this is what you count.
    public List<HttpRequestMessage> Requests { get; } = new();

    // The serialized body of each request, captured while it is still readable.
    public List<string?> Bodies { get; } = new();
    public string? LastBody => Bodies.Count == 0 ? null : Bodies[^1];
    public HttpRequestMessage? LastRequest => Requests.Count == 0 ? null : Requests[^1];

    public StubHandler(Func<HttpRequestMessage, HttpResponseMessage> responder) => _responder = responder;

    protected override Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request, CancellationToken ct)
    {
        Requests.Add(request);
        // Buffer the body NOW — see the note below; it is gone by the time your test runs.
        Bodies.Add(request.Content is null ? null : request.Content.ReadAsStringAsync().Result);
        var response = _responder(request);
        response.RequestMessage = request;   // real HttpClient sets this; some retry predicates read it
        return Task.FromResult(response);
    }
}

static {Api}Client ClientReturning(HttpStatusCode status, string json)
{
    var handler = new StubHandler(_ => new HttpResponseMessage(status)
    {
        Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json")
    });
    return new {Api}Client(new HttpClient(handler), new {Api}ClientOptions { /* auth not needed for stubs */ });
}
```

## Test a success path

```csharp
[Fact]
public async Task ReturnsDeserializedBody()
{
    var client = ClientReturning(HttpStatusCode.OK, """{ "{resource}": { "id": 123 } }""");

    var response = await client.{ApiGroup}.{Operation}(request, cancellationToken: default);

    Assert.Equal(123, response.{Resource}?.Id);
}
```

## Test an error path

Endpoint methods throw `ApiException<TError>` on non-2xx (see `dotnet-error-handling`). `TError` is the
operation's `{Operation}Error` model (**Case A**) for operations that have a generated `{Operation}Error`
type, or `RawError` **directly** (**Case B**) otherwise — so assert the type that matches your operation.
Whichever the case, the exception itself carries `StatusCode`, `Headers` and `ContentType` (from
`ApiException`) plus the failed call's `Method` and `RequestUri` (from the `SdkException` root), and its
`Message` is the call and the status — `"POST https://host/path returned 422 (UnprocessableEntity)."`.

**Case A — typed `{Operation}Error`:**

```csharp
using {RootNamespace}.Core.Exceptions;     // ApiException<TError>
using {RootNamespace}.Errors;              // {Operation}Error types

[Fact]
public async Task ThrowsOnApiError()
{
    var client = ClientReturning(HttpStatusCode.UnprocessableEntity, """{ "errors": ["bad input"] }""");

    var ex = await Assert.ThrowsAsync<ApiException<{Operation}Error>>(
        () => client.{ApiGroup}.{Operation}(request, cancellationToken: default));

    Assert.Equal(HttpStatusCode.UnprocessableEntity, ex.StatusCode);   // the status is on the exception
    // ex.Error is the typed ApiError. For a status the operation maps to a typed body (e.g. 422), assert the
    // typed accessor — its name embeds the body type; the contract sheet lists the exact accessor name.
    // TryGetRawError is FALSE for those statuses, so don't assert through it here:
    Assert.True(ex.Error.TryGetSomeTypedBody(out var typed));
    // ...assert on 'typed'. TryGetRawError fires ONLY for a status that falls to the error factory's
    // default arm. A status with its own RawError accessor — TryGetNoContent, say — populates that
    // accessor and leaves TryGetRawError false, so assert the specific one.
}
```

**Case B — `ApiException<RawError>`** (e.g. read/list/find/archive/delete operations). Here `ex.Error` *is*
the `RawError` — there is no `TryGet*` / `TryGetRawError`; read it directly:

```csharp
using {RootNamespace}.Core.Exceptions;
using {RootNamespace}.Core.ErrorResponse;

var ex = await Assert.ThrowsAsync<ApiException<RawError>>(
    () => client.{ApiGroup}.{Operation}(request, cancellationToken: default));

Assert.Equal(HttpStatusCode.UnprocessableEntity, ex.StatusCode);   // same value as ex.Error.StatusCode
// You can also assert the deserialized error body: ex.Error.ReadAsString() / ex.Error.ReadAsJson<MyDto>().
```

**A body that does not match the model is a third outcome.** Stub a 2xx whose JSON does not fit the
response type — or an error status whose body does not fit the `{Operation}Error` template — and the call
throws `ResponseDeserializationException`: an `ApiException` (so `StatusCode` tells you which of the two it
was) but **not** an `ApiException<TError>`, carrying the `TargetType` it tried to build and the
`JsonException` as `InnerException`. Lock this down for any operation whose provider is known to drift:

```csharp
var client = ClientReturning(HttpStatusCode.OK, """{ "{resource}": "not-an-object" }""");

var ex = await Assert.ThrowsAsync<ResponseDeserializationException>(
    () => client.{ApiGroup}.{Operation}(request, cancellationToken: default));

Assert.Equal(HttpStatusCode.OK, ex.StatusCode);
Assert.Equal(typeof({ReturnType}), ex.TargetType);
```

## Test the result-style (`ApiResult`) variant

If the operation exposes the optional non-throwing `{Operation}Result` sibling (see `dotnet-error-handling`),
there is nothing to catch — stub the response and assert on the returned `ApiResult<TResponse, TError>`
directly. The status code and headers are available on both the success and failure outcomes.

```csharp
using {RootNamespace}.Core.Models;        // ApiResult<TResponse, TError>
using {RootNamespace}.Core.ErrorResponse; // RawError (Case B)
using {RootNamespace}.Errors;             // {Operation}Error (Case A only)

[Fact]
public async Task ResultVariantReportsFailureWithoutThrowing()
{
    var client = ClientReturning(HttpStatusCode.UnprocessableEntity, """{ "errors": ["bad input"] }""");

    var result = await client.{ApiGroup}.{Operation}Result(request, cancellationToken: default);

    Assert.False(result.TryGetResponse(out _));
    Assert.True(result.TryGetError(out var error));   // 'error' is the same TError as the throwing path
    Assert.Equal(HttpStatusCode.UnprocessableEntity, result.StatusCode);
    // 'error' is a typed {Operation}Error (Case A) or a RawError (Case B) — assert accordingly.
}
```

## Test a client with OAuth credentials

With OAuth credentials set, the first request your stub sees is the token `POST`. `ClientReturning` answers
every request alike, so give `StubHandler` a responder that returns queued responses, a token response such as
`{ "access_token": "t", "token_type": "Bearer" }` first. The token is cached, so two calls make three
requests. Or keep the credentials set and give `options.{Scheme}TokenStrategy` a stub that returns
`new OAuthToken { AccessToken = "t", TokenType = "Bearer" }` (for authorization code, an
`OAuthTokenRefreshable`, with `TryRefreshToken` returning `null`), because a strategy without credentials is
never used. Either way, an authorization-code client also needs a `PromptForAuthorizationCode` that returns a
fixed code.
For a bad-credentials test, answer the token request with a 4xx and assert `AuthSchemeException`.

## Fake the clock

The SDK reads time through exactly one seam — `{Api}ClientOptions.TimeProvider` (default
`TimeProvider.System`). Retry backoff, `Retry-After`, the per-attempt timeout, the SSE idle timeout, OAuth2
token expiry and the logged request durations all follow it, so one fake provider drives them together and
a retry test no longer sleeps through `1s + 2s + 4s` of real backoff. Use a provider that **implements
timers** — `FakeTimeProvider` from `Microsoft.Extensions.TimeProvider.Testing` — because the retry delay
and the idle window are timers on the provider: a `GetUtcNow`-only fake throws when the SDK asks it for a
timer, which is deliberate and better than a silent real sleep.

```csharp
using Microsoft.Extensions.Time.Testing;   // FakeTimeProvider (Microsoft.Extensions.TimeProvider.Testing)

var clock = new FakeTimeProvider();
var responses = new Queue<HttpStatusCode>([HttpStatusCode.ServiceUnavailable, HttpStatusCode.OK]);
var handler = new StubHandler(_ => new HttpResponseMessage(responses.Dequeue()) { Content = new StringContent("{}") });
var client = new {Api}Client(new HttpClient(handler), new {Api}ClientOptions { TimeProvider = clock });

var call = client.{ApiGroup}.{Operation}(request, cancellationToken: default);   // a GET: retryable
clock.Advance(TimeSpan.FromSeconds(2));                              // past the 1s backoff (+ up to 500ms jitter)
await call;

Assert.Equal(2, handler.Requests.Count);
```

The awaited call does not complete until the fake clock moves past the backoff — start the call, `Advance`,
then `await`. Under DI, register the fake as the container's `TimeProvider` (before *or* after
`Add{Api}Client` — order does not matter) and the SDK seeds the option from it; an explicit
`o.TimeProvider = clock` in the configure callback wins over the container. The SDK never registers a
`TimeProvider` itself, so nothing of yours is overwritten.

## Construct an SDK exception directly

When the code under test takes the SDK's exception as *input* — an error-mapping boundary, a retry policy of
your own — build the leaf directly instead of driving a stub through the whole client. Every leaf has a
public primary constructor taking the message and its cause (`(string message, Exception? innerException =
null)` on most; `ResponseDeserializationException` requires the cause, `AuthSchemeException` takes the list
of scheme failures) and sets its `required` members through the object initializer; there is no
`[SetsRequiredMembers]` shortcut, so a fake states the full call identity exactly as the SDK does (the
`For(...)` factories are `internal` because they take engine types):

```csharp
using {RootNamespace}.Core.Exceptions;

var timeout = new SdkTimeoutException("GET https://api.example.com/widgets received no response within 10 s.")
{
    Method = HttpMethod.Get,
    RequestUri = new Uri("https://api.example.com/widgets"),
    Timeout = TimeSpan.FromSeconds(10),
};

var unreadable = new ResponseDeserializationException(
    "GET https://api.example.com/widgets returned a body that could not be deserialized into Widget.",
    new System.Text.Json.JsonException("..."))
{
    Method = HttpMethod.Get,
    RequestUri = new Uri("https://api.example.com/widgets"),
    StatusCode = HttpStatusCode.OK,
    Headers = new HttpResponseMessage().Headers,
    ContentType = null,
    TargetType = typeof(Widget),
};
```

`ApiException<TError>` is the one leaf you cannot fabricate: neither `RawError` nor a `{Operation}Error` has
a public constructor. Produce it through the stub handler as in *Test an error path* above.

## Assert the outgoing request

Because the stub captures `LastRequest`, you can assert method, path, query, headers, and body:

```csharp
var handler = new StubHandler(_ => new HttpResponseMessage(HttpStatusCode.OK)
                                   { Content = new StringContent("{}") });
var client = new {Api}Client(new HttpClient(handler), new {Api}ClientOptions());

await client.{ApiGroup}.{Operation}(request, cancellationToken: default);

Assert.Equal(HttpMethod.Post, handler.LastRequest!.Method);
Assert.Contains("/expected/path", handler.LastRequest!.RequestUri!.AbsolutePath);
Assert.Contains("per_page=20", handler.LastRequest!.RequestUri!.Query);  // query params are snake_case on the wire

// Assert the serialized request body of a POST/PUT/PATCH:
var sentJson = handler.LastBody;   // NOT LastRequest.Content — see below
Assert.Contains("\"expected_field\"", sentJson);
```

## Notes

- ⚠ **Read the request body inside the handler, never off the captured request afterwards.** The SDK
  disposes the request content in a `finally` that runs per attempt, *inside* the pipeline — so by the time
  your awaited call returns, `handler.LastRequest.Content.ReadAsStringAsync()` throws
  `ObjectDisposedException`. That is why the stub above buffers `Bodies` during `SendAsync`. Everything
  else on the captured `HttpRequestMessage` — method, URI, headers — survives and can be asserted normally.
- Mocking libraries (Moq, NSubstitute) work too — mock `HttpMessageHandler.SendAsync` (it's `protected`,
  so use `Protected()` with Moq). The hand-written stub above avoids that friction.
- A stubbed retryable response — the default set is exactly `408, 429, 500, 502, 503, 504`, not all `5xx`
  — on a retryable method will be retried by the SDK before the call returns. `HttpMethodsToRetry` (`GET/HEAD/PUT/OPTIONS` by default) gates **every** trigger, so a
  `POST` retries on nothing — not a `503`, not a thrown `HttpRequestException`, not the per-attempt timeout
  — unless you add its verb to the list (see `dotnet-configuration-resilience`). To observe retries firing,
  stub a `GET` that returns `503` then `200` and count invocations.
- **Status faults and transport faults are separate retry triggers** — the SDK distinguishes them itself
  (`RetryAttempt.Reason` is `RetryReason.Status(...)` *or* `RetryReason.Failure(Exception)`), and a third,
  the per-attempt timeout, arrives as `RetryReason.Failure(TimeoutRejectedException)`. A test that stubs a
  `503` therefore proves nothing about what happens when the *connection* fails. The verb filter holds all
  three at one send for a `POST` — which is exactly the property worth locking down with a test, because it
  is a *configuration* guarantee and someone widening `HttpMethodsToRetry` for the read path silently
  removes it. What reaches the test is the SDK's wrapper, never the raw `HttpRequestException`: a failed
  send surfaces as `SdkConnectionException` (message `"POST https://host/path could not be sent: connection
  reset"`, the raw exception as `InnerException`), and an exhausted per-attempt timeout as
  `SdkTimeoutException` with `Timeout` set to the window that elapsed.
  ```csharp
  // Transport fault: the stub throws instead of answering, then we count what the server actually received.
  var handler = new StubHandler(_ => throw new HttpRequestException("connection reset"));
  var client = new {Api}Client(new HttpClient(handler), new {Api}ClientOptions());

  var ex = await Assert.ThrowsAsync<SdkConnectionException>(
      () => client.{ApiGroup}.{Operation}(request, cancellationToken: default));

  Assert.IsType<HttpRequestException>(ex.InnerException);
  Assert.Equal(1, handler.Requests.Count(r => r.Method == HttpMethod.Post));   // no resend
  ```
- **Your own cancellation is the one thing the SDK never wraps.** A token you cancel surfaces as the usual
  `OperationCanceledException` / `TaskCanceledException`, not as an `SdkException` — so a test that cancels
  mid-call asserts on the framework type, and a `catch (SdkException)` in the code under test must be
  expected *not* to fire.
- For DI-based code, the SDK's `Add{Api}Client` resolves the **default (unnamed)** `IHttpClientFactory`
  client, so register your stub on that one, then resolve `{Api}Client` from the provider:
  ```csharp
  services.Add{Api}Client(o => { /* ... */ });
  services.AddHttpClient(Options.DefaultName).ConfigurePrimaryHttpMessageHandler(() => stubHandler);
  var client = services.BuildServiceProvider().GetRequiredService<{Api}Client>();
  ```
  A `TimeProvider` registered in the same container is picked up by the SDK automatically — see *Fake the
  clock* below.
- To look up an operation's signature, its request type, or a `{Operation}Error`'s accessor names, take them
  from the contract sheet (grounded from the SDK map/source) — not a decompiled or
  reflected view of the installed package, and not memory.
- Prefer this `HttpClient`-seam approach over wrapping the SDK in your own interface unless you need to
  abstract the SDK for other reasons.
